import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { ResultDisplay } from './components/ResultDisplay';
import { Footer } from './components/Footer';
import { generateLookbook, generateBroll, generateVideoPrompt, generatePoses } from './services/geminiService';
import type { ImageData, Look } from './types';
import { AboutModal } from './components/AboutModal';
import { Faq } from './components/Faq';
import { Disclaimer } from './components/Disclaimer';

type GenerationMode = 'lookbook' | 'b-roll' | 'pose';

const VALID_MIME_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

const App: React.FC = () => {
  const [modelImage, setModelImage] = useState<ImageData | null>(null);
  const [modelImagePreview, setModelImagePreview] = useState<string | null>(null);

  // Use arrays to handle multiple product images
  const [productImages, setProductImages] = useState<(ImageData | null)[]>([null]);
  const [productImagePreviews, setProductImagePreviews] = useState<(string | null)[]>([null]);

  const [lookbook, setLookbook] = useState<Look[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [promptLoadingIndex, setPromptLoadingIndex] = useState<number | null>(null);

  const [theme, setTheme] = useState<string>('Studio Professional');
  const [lighting, setLighting] = useState<string>('Natural Light');
  const [generationMode, setGenerationMode] = useState<GenerationMode>('lookbook');
  
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);

  const handleOpenAboutModal = () => setIsAboutModalOpen(true);
  const handleCloseAboutModal = () => setIsAboutModalOpen(false);
  
  const fileToImageData = (file: File): Promise<ImageData> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const mimeType = result.split(';')[0].split(':')[1];
        const base64 = result.split(',')[1];
        resolve({ base64, mimeType });
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleModelImageUpload = useCallback(async (file: File) => {
    if (!VALID_MIME_TYPES.includes(file.type)) {
      setError(`Unsupported file type: '${file.type}'. Please upload a PNG, JPG, or WEBP file.`);
      return;
    }
    setError(null);
    setModelImagePreview(URL.createObjectURL(file));
    const imageData = await fileToImageData(file);
    setModelImage(imageData);
  }, []);
  
  const handleModelImageRemove = useCallback(() => {
    setModelImage(null);
    setModelImagePreview(null);
  }, []);

  const handleProductImageUpload = useCallback(async (file: File, index: number) => {
    if (!VALID_MIME_TYPES.includes(file.type)) {
      setError(`Unsupported file type: '${file.type}'. Please upload a PNG, JPG, or WEBP file.`);
      return;
    }
    setError(null);
    const newPreviews = [...productImagePreviews];
    newPreviews[index] = URL.createObjectURL(file);
    setProductImagePreviews(newPreviews);

    const imageData = await fileToImageData(file);
    const newImages = [...productImages];
    newImages[index] = imageData;
    setProductImages(newImages);
  }, [productImages, productImagePreviews]);
  
  const handleProductImageRemove = useCallback((index: number) => {
    // For the main product (index 0), just clear it. For accessories, remove the slot.
    if (index === 0) {
        const newPreviews = [...productImagePreviews];
        newPreviews[0] = null;
        setProductImagePreviews(newPreviews);
        
        const newImages = [...productImages];
        newImages[0] = null;
        setProductImages(newImages);
    } else {
        setProductImagePreviews(prev => prev.filter((_, i) => i !== index));
        setProductImages(prev => prev.filter((_, i) => i !== index));
    }
  }, [productImages, productImagePreviews]);
  
  const handleAddProductSlot = useCallback(() => {
    if (productImages.length < 4) {
      setProductImages(prev => [...prev, null]);
      setProductImagePreviews(prev => [...prev, null]);
    }
  }, [productImages.length]);

  const handleGenerate = async () => {
    setIsLoading(true);
    setError(null);
    setLookbook(null);

    try {
      let images: string[] | null = null;
      if (generationMode === 'lookbook') {
        const validProductImages = productImages.filter(Boolean) as ImageData[];
        if (!modelImage || validProductImages.length === 0) {
          setError("Please upload a model and at least one product image for Lookbook mode.");
          setIsLoading(false);
          return;
        }
        images = await generateLookbook(modelImage, validProductImages, theme, lighting);
      } else if (generationMode === 'b-roll') {
         const mainProduct = productImages[0];
        if (!mainProduct) {
          setError("Please upload a product image for B-roll mode.");
          setIsLoading(false);
          return;
        }
        images = await generateBroll(mainProduct, theme, lighting);
      } else { // Pose mode
         if (!modelImage) {
          setError("Please upload a model image for Pose mode.");
          setIsLoading(false);
          return;
        }
        images = await generatePoses(modelImage, theme, lighting);
      }
      
      if (images && images.length > 0) {
        const newLookbook = images.map(url => ({ imageUrl: url, videoPrompt: null }));
        setLookbook(newLookbook);
      } else {
        setError("The AI could not generate images. Please try a different set of images or settings.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGeneratePrompt = async (index: number) => {
    if (!lookbook) {
       setError("Cannot generate prompt without a lookbook.");
       return;
    }
    
    setPromptLoadingIndex(index);
    try {
      const look = lookbook[index];
      const response = await fetch(look.imageUrl);
      const blob = await response.blob();
      const file = new File([blob], `look-${index}.png`, { type: blob.type });
      const imageData = await fileToImageData(file);
      
      const prompt = await generateVideoPrompt(imageData, theme, lighting);

      setLookbook(currentLookbook => {
        if (!currentLookbook) return null;
        const newLookbook = [...currentLookbook];
        newLookbook[index] = { ...newLookbook[index], videoPrompt: prompt };
        return newLookbook;
      });

    } catch (err) {
      // You might want to show a small error message near the button
      console.error("Failed to generate video prompt:", err);
    } finally {
      setPromptLoadingIndex(null);
    }
  };

  const canGenerate = (generationMode === 'lookbook' 
      ? (!!modelImage && !!productImages[0])
      : (generationMode === 'b-roll' ? !!productImages[0] : !!modelImage)
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 flex flex-col font-sans">
      <Header 
        onOpenAbout={handleOpenAboutModal} 
      />
      <main className="flex-grow container max-w-screen-xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Stylook - AI Product Showcase</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Create stunning, AI-generated lookbooks or product B-rolls for your affiliate campaigns in seconds.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          <ControlPanel
            generationMode={generationMode}
            setGenerationMode={setGenerationMode}
            onModelUpload={handleModelImageUpload}
            onModelRemove={handleModelImageRemove}
            modelPreviewUrl={modelImagePreview}
            productPreviews={productImagePreviews}
            onProductUpload={handleProductImageUpload}
            onProductRemove={handleProductImageRemove}
            onAddProductSlot={handleAddProductSlot}
            theme={theme}
            setTheme={setTheme}
            lighting={lighting}
            setLighting={setLighting}
            onGenerate={handleGenerate}
            isLoading={isLoading}
            canGenerate={canGenerate}
          />
          <ResultDisplay 
            lookbook={lookbook}
            isLoading={isLoading}
            error={error}
            onGeneratePrompt={handleGeneratePrompt}
            promptLoadingIndex={promptLoadingIndex}
            generationMode={generationMode}
          />
        </div>
        
        <Disclaimer />
        <Faq />

      </main>
      <Footer />
      <AboutModal isOpen={isAboutModalOpen} onClose={handleCloseAboutModal} />
    </div>
  );
};

export default App;