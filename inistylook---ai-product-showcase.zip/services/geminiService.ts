import { GoogleGenAI, Modality } from "@google/genai";
import type { GenerateContentResponse, Part } from "@google/genai";
import type { ImageData } from "../types";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });


const lookPrompts = [
  "in a confident walking pose on a city street, full-body shot.",
  "sitting elegantly at an outdoor cafe, medium shot.",
  "in a dynamic studio shot with a solid, light-colored background.",
  "leaning against a rustic brick wall, casual pose.",
  "in a close-up shot focusing on the details of the fashion item.",
  "in a minimalist indoor setting with natural light, looking away from the camera.",
];

const brollPrompts = [
  "in an extreme close-up shot, highlighting the material, texture, and intricate details of the product.",
  "photographed from a dramatic low-angle, making the product appear monumental and aspirational.",
  "in an artfully arranged flat lay composition, surrounded by subtle props that complement the product's function and aesthetic.",
  "showcased on a geometric pedestal (e.g., marble, wood, or metal) with professional, focused studio lighting that creates elegant shadows.",
  "in a contextually relevant lifestyle scene. The background should logically match the product's category (e.g., a stylish desk for a gadget, a serene bathroom for a cosmetic product).",
  "deconstructed or with its components elegantly laid out, revealing its inner workings or ingredients in a visually appealing way.",
];

const posePrompts = [
    "striking a dynamic action pose, as if captured mid-motion.",
    "in a relaxed, seated pose on a minimalist chair or stool.",
    "a powerful, confident stance with hands on hips.",
    "a graceful, elegant pose with arms outstretched or in a dance-like position.",
    "a thoughtful, contemplative pose, looking away from the camera.",
    "a close-up beauty shot, focusing on the face and shoulders with a subtle expression.",
];

const parseAndThrowEnhancedError = (error: unknown) => {
    console.error("Gemini Service Error:", error);
    if (error instanceof Error) {
        const message = error.message.toLowerCase();
        if (message.includes('api key not valid')) {
            throw new Error('The API key is invalid. Please check your key and try again.');
        }
        if (message.includes('permission denied') || message.includes('origin')) {
            throw new Error('API request blocked. Your API key may have domain restrictions. Please check your Google Cloud Console to ensure your domain is whitelisted.');
        }
        if (message.includes('quota')) {
            throw new Error('You have exceeded your API quota. Please check your usage limits in your Google Cloud account.');
        }
    }
    throw new Error("Failed to communicate with the AI service. The service may be busy or the images may not be suitable.");
}

const generateSingleLook = async (
  modelImage: ImageData,
  productImages: ImageData[],
  stylePrompt: string,
  theme: string,
  lighting: string
): Promise<string> => {
    
  let promptSegment = "wearing the main fashion item from the second image";
  if (productImages.length > 1) {
      promptSegment += " and the accessories from the subsequent images";
  }

  const prompt = `Important: The output image MUST have a 9:16 aspect ratio (portrait format). Create a new, photorealistic image of the model from the first image ${promptSegment} ${stylePrompt}. The photoshoot theme is '${theme}' with '${lighting}'. The overall style should be suitable for a high-end fashion lookbook. The background must match the theme.`;

  const modelImagePart: Part = {
    inlineData: { data: modelImage.base64, mimeType: modelImage.mimeType },
  };

  const textPart: Part = { text: prompt };

  const productImageParts: Part[] = productImages.map(image => ({
    inlineData: { data: image.base64, mimeType: image.mimeType },
  }));

  const parts: Part[] = [modelImagePart, textPart, ...productImageParts];

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: parts,
    },
    config: {
      responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  if (response.candidates && response.candidates.length > 0) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }

  throw new Error("The AI model did not return a valid image for one of the looks.");
};


export const generateLookbook = async (
  modelImage: ImageData,
  productImages: ImageData[],
  theme: string,
  lighting: string
): Promise<string[]> => {
  try {
    const imagePromises = lookPrompts.map(style => 
      generateSingleLook(modelImage, productImages, style, theme, lighting)
    );
    
    const imageUrls = await Promise.all(imagePromises);
    
    return imageUrls.filter(url => !!url);

  } catch (error) {
    parseAndThrowEnhancedError(error);
    return []; // This line is unreachable but required by TypeScript
  }
};

const generateSingleBrollShot = async (
  productImage: ImageData,
  stylePrompt: string,
  theme: string,
  lighting: string
): Promise<string> => {
  const prompt = `Important: The output image MUST have a 9:16 aspect ratio (portrait format). Generate a new, photorealistic B-roll image of ONLY the product from the provided image. The generated background and props MUST be logically appropriate for the product category (e.g., a handbag on a stylish table, not in a forest). Now, apply this specific style: ${stylePrompt}. The photoshoot theme is '${theme}' with '${lighting}'. The overall style should be suitable for a high-end product showcase. Do NOT include any people or models in the image.`;
  
  const productImagePart: Part = {
    inlineData: { data: productImage.base64, mimeType: productImage.mimeType },
  };
  
  const textPart: Part = { text: prompt };

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [productImagePart, textPart],
    },
    config: {
      responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  if (response.candidates && response.candidates.length > 0) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }

  throw new Error("The AI model did not return a valid image for one of the B-roll shots.");
};

export const generateBroll = async (
  productImage: ImageData,
  theme: string,
  lighting: string
): Promise<string[]> => {
  try {
    const imagePromises = brollPrompts.map(style => 
      generateSingleBrollShot(productImage, style, theme, lighting)
    );
    
    const imageUrls = await Promise.all(imagePromises);
    
    return imageUrls.filter(url => !!url);

  } catch (error) {
    parseAndThrowEnhancedError(error);
    return []; // This line is unreachable but required by TypeScript
  }
};

const generateSinglePose = async (
  modelImage: ImageData,
  stylePrompt: string,
  theme: string,
  lighting: string
): Promise<string> => {
  const prompt = `Important: The output image MUST have a 9:16 aspect ratio (portrait format). Recreate the exact same model from the image, wearing the same clothes in the same environment. The only thing that should change is their pose. The new pose should be: ${stylePrompt}. The photoshoot theme is '${theme}' with '${lighting}'. Maintain photorealism and consistency with the original image.`;
  
  const modelImagePart: Part = {
    inlineData: { data: modelImage.base64, mimeType: modelImage.mimeType },
  };

  const textPart: Part = { text: prompt };

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [modelImagePart, textPart],
    },
    config: {
      responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  if (response.candidates && response.candidates.length > 0) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }

  throw new Error("The AI model did not return a valid image for one of the poses.");
};

export const generatePoses = async (
  modelImage: ImageData,
  theme: string,
  lighting: string
): Promise<string[]> => {
  try {
    const imagePromises = posePrompts.map(style => 
      generateSinglePose(modelImage, style, theme, lighting)
    );
    
    const imageUrls = await Promise.all(imagePromises);
    
    return imageUrls.filter(url => !!url);

  } catch (error) {
    parseAndThrowEnhancedError(error);
    return []; // This line is unreachable but required by TypeScript
  }
};


export const generateVideoPrompt = async (
    image: ImageData,
    theme: string,
    lighting: string
): Promise<string> => {
    try {
        const prompt = `You are a creative director for a fashion video shoot. Look at this image, which has a theme of '${theme}' and '${lighting}' lighting. Write a short, concise, and dynamic prompt for an Image-to-Video AI model like VEO or Kling. The prompt should describe a subtle movement or action that feels natural to the scene and showcases the product. Output a single sentence only. Do not describe what is already in the image, only describe the action.`;
        
        const imagePart: Part = {
            inlineData: { data: image.base64, mimeType: image.mimeType },
        };
        const textPart: Part = { text: prompt };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [imagePart, textPart],
            },
        });

        const videoPrompt = response.text.trim();
        if (!videoPrompt) {
            throw new Error("AI failed to generate a video prompt.");
        }
        return videoPrompt;

    } catch (error) {
        parseAndThrowEnhancedError(error);
        return ""; // This line is unreachable but required by TypeScript
    }
};