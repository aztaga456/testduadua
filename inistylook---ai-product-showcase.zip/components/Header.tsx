
import React from 'react';

interface HeaderProps {
  onOpenAbout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAbout }) => {
  return (
    <header className="bg-gray-900 border-b border-gray-700 sticky top-0 z-50">
      <div className="container max-w-screen-xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
          <h1 className="text-xl font-bold text-white flex items-baseline">
            <span>Stylook</span>
            <span className="text-sm font-light text-gray-300 ml-2">by IniPrompt</span>
          </h1>
        </div>
        <div className="flex items-center space-x-6">
          <button
            onClick={onOpenAbout}
            className="font-semibold text-gray-300 hover:text-white transition-colors"
            aria-label="About this application"
          >
            About
          </button>
        </div>
      </div>
    </header>
  );
};
