import React, { useState } from 'react';
import { Spinner } from './Spinner';
import type { Look } from '../types';
import { ImageZoomModal } from './ImageZoomModal';

interface ResultDisplayProps {
  lookbook: Look[] | null;
  isLoading: boolean;
  error: string | null;
  onGeneratePrompt: (index: number) => void;
  promptLoadingIndex: number | null;
  generationMode: 'lookbook' | 'b-roll' | 'pose';
}

const LoadingMessage: React.FC = () => {
    const messages = [
        "Warming up the AI stylist...",
        "Designing your content...",
        "Capturing the perfect angles...",
        "This magical transformation takes a moment...",
        "Styling each shot...",
        "Assembling your showcase..."
    ];
    const [message, setMessage] = React.useState(messages[0]);

    React.useEffect(() => {
        const interval = setInterval(() => {
            setMessage(messages[Math.floor(Math.random() * messages.length)]);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return <p className="text-gray-600 mt-4 text-lg">{message}</p>;
}

const LookCard: React.FC<{ look: Look; index: number; onGeneratePrompt: (index: number) => void; isLoading: boolean; onZoom: (imageUrl: string) => void; }> = ({ look, index, onGeneratePrompt, isLoading, onZoom }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        if (look.videoPrompt) {
            navigator.clipboard.writeText(look.videoPrompt);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const ZoomButton: React.FC<{ isSecondary?: boolean }> = ({ isSecondary = false }) => (
        <button
            onClick={() => onZoom(look.imageUrl)}
            className={`font-bold py-2 px-4 rounded-lg transition-all flex items-center justify-center space-x-2 text-sm border-2 border-gray-900 w-full ${isSecondary ? 'bg-gray-800 hover:bg-gray-900 text-white' : 'bg-white hover:bg-gray-200 text-gray-900'}`}
            aria-label={`Zoom in on look ${index + 1}`}
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
            </svg>
            <span>Zoom</span>
        </button>
    );

    const DownloadButton: React.FC<{ isSecondary?: boolean }> = ({ isSecondary = false }) => (
        <a
            href={look.imageUrl}
            download={`look-${index + 1}.png`}
            className={`font-bold py-2 px-4 rounded-lg transition-all flex items-center justify-center space-x-2 text-sm border-2 border-gray-900 w-full ${isSecondary ? 'bg-gray-800 hover:bg-gray-900 text-white' : 'bg-white hover:bg-gray-200 text-gray-900'}`}
            aria-label={`Download look ${index + 1}`}
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
            <span>Download</span>
        </a>
    );

    return (
        <div className="relative group overflow-hidden rounded-lg border-2 border-gray-900 aspect-[9/16] bg-gray-100 shadow-[4px_4px_0px_#111827]">
            <img src={look.imageUrl} alt={`Look ${index + 1}`} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
            <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-2">
                {look.videoPrompt ? (
                    <div className="text-center text-white p-2 flex flex-col justify-center items-center h-full w-full">
                        <p className="text-sm mb-3 font-mono flex-grow overflow-y-auto custom-scrollbar">{look.videoPrompt}</p>
                        <div className="w-full space-y-2 mt-auto">
                            <button
                                onClick={handleCopy}
                                className="bg-white hover:bg-gray-200 text-gray-900 font-bold py-2 px-4 rounded-lg transition-all text-sm border-2 border-gray-900 w-full"
                            >
                                {copied ? 'Copied!' : 'Copy Prompt'}
                            </button>
                             <ZoomButton isSecondary={true} />
                            <DownloadButton isSecondary={true} />
                        </div>
                    </div>
                ) : (
                    <div className="flex flex-col space-y-3">
                        <ZoomButton />
                        <DownloadButton />
                        <button
                            onClick={() => onGeneratePrompt(index)}
                            disabled={isLoading}
                            className="bg-gray-800 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded-lg transition-all flex items-center justify-center space-x-2 text-sm border-2 border-gray-900 disabled:bg-gray-500"
                            aria-label={`Generate video prompt for look ${index + 1}`}
                        >
                            {isLoading ? (
                                <>
                                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <span>Generating...</span>
                                </>
                            ) : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M10 3.5a1.5 1.5 0 011.5 1.5v1.41a3.501 3.501 0 00-2.532 1.222l-.678.79a.5.5 0 01-.88.002l-.68-.79A3.5 3.5 0 004 6.41V5A1.5 1.5 0 015.5 3.5h3zm-2.5 7.5a.5.5 0 000 1h5a.5.5 0 000-1h-5z" />
                                        <path fillRule="evenodd" d="M2 5a3 3 0 013-3h6a3 3 0 013 3v10a3 3 0 01-3 3H5a3 3 0 01-3-3V5zm3-1a1 1 0 00-1 1v10a1 1 0 001 1h6a1 1 0 001-1V5a1 1 0 00-1-1H5z" clipRule="evenodd" />
                                    </svg>
                                    <span>Generate Prompt</span>
                                </>
                            )}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ lookbook, isLoading, error, onGeneratePrompt, promptLoadingIndex, generationMode }) => {
  const [zoomedImageUrl, setZoomedImageUrl] = useState<string | null>(null);
  const isLookbookMode = generationMode === 'lookbook';
  const isPoseMode = generationMode === 'pose';
  
  const handleZoomIn = (imageUrl: string) => {
    setZoomedImageUrl(imageUrl);
  };

  const handleZoomOut = () => {
    setZoomedImageUrl(null);
  };

  const getTitle = () => {
    if (isLookbookMode) return 'Your Fashion Lookbook!';
    if (isPoseMode) return 'Your Model Poses!';
    return 'Your Product B-roll!';
  }

  const getPlaceholderSubject = () => {
    if (isLookbookMode) return 'looks';
    if (isPoseMode) return 'poses';
    return 'shots';
  }
  
  const getPlaceholderInstruction = () => {
      if (isLookbookMode) return 'Upload images, choose your settings on the left, and click "Create Lookbook" to begin.';
      if (isPoseMode) return 'Upload a model, choose your settings on the left, and click "Create Poses" to begin.';
      return 'Upload a product, choose your settings on the left, and click "Create B-roll" to begin.';
  }

  return (
    <div className="w-full bg-white border-2 border-gray-900 rounded-xl shadow-[8px_8px_0px_#111827] p-4 md:p-6 min-h-[400px] flex justify-center items-center sticky top-28">
      <div className="w-full text-center">
        {isLoading && (
          <div className="flex flex-col items-center">
            <Spinner />
            <LoadingMessage />
          </div>
        )}
        {error && !isLoading && (
          <div className="text-red-700 bg-red-100 p-4 rounded-lg border-2 border-red-700">
            <p className="font-semibold">An Error Occurred</p>
            <p>{error}</p>
          </div>
        )}
        {!isLoading && !error && lookbook && lookbook.length > 0 && (
          <div>
            <h3 className="text-2xl font-bold mb-6 text-gray-900">
              {getTitle()}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {lookbook.map((look, index) => (
                <LookCard 
                    key={index}
                    look={look}
                    index={index}
                    onGeneratePrompt={onGeneratePrompt}
                    isLoading={promptLoadingIndex === index}
                    onZoom={handleZoomIn}
                />
              ))}
            </div>
          </div>
        )}
        {!isLoading && !error && !lookbook && (
          <div className="text-gray-500">
            <p className="text-xl font-semibold">Your generated {getPlaceholderSubject()} will appear here.</p>
            <p className="text-md mt-2 max-w-sm mx-auto">
              {getPlaceholderInstruction()}
            </p>
          </div>
        )}
      </div>
       <ImageZoomModal imageUrl={zoomedImageUrl} onClose={handleZoomOut} />
    </div>
  );
};